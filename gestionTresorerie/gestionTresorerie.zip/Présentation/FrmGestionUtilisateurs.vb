﻿Imports System.Data.SqlClient

Public Class FrmGestionUtilisateurs
    Private Shared Function CreateUtilisateurRepository() As UtilisateurRepository
        Dim connectionString As String =
        ConnexionDB.GetInstance(Constantes.DataBases.Agumaaa).
                    GetConnexion(Constantes.DataBases.Agumaaa).
                    ConnectionString

        Dim factory As New AgumaaaConnectionFactory(connectionString)
        Dim provider As ISqlTextProvider = New LegacySqlTextProvider()
        Dim executor As ISqlExecutor = New SqlExecutor(factory, provider)

        Return New UtilisateurRepository(executor)
    End Function
    Private Sub FrmGestionUtilisateurs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ChargerUtilisateurs()
    End Sub

    Private Sub ChargerUtilisateurs()
        dgvUtilisateurs.Rows.Clear()
        Try
            Using cn As New SqlConnection(LectureProprietes.connexionString(Constantes.DataBases.Agumaaa))
                cn.Open()

                Dim cmd As New SqlCommand("SELECT Id, NomUtilisateur, Role, Actif FROM Utilisateurs ORDER BY NomUtilisateur", cn)
                Using rdr = cmd.ExecuteReader()
                    While rdr.Read()
                        Dim unused1 = dgvUtilisateurs.Rows.Add(rdr.GetInt32(0),
                                                 rdr.GetString(1),
                                                 rdr.GetString(2),
                                                 rdr.GetBoolean(3))
                    End While
                End Using
            End Using
        Catch ex As Exception
            Dim unused = MessageBox.Show("Erreur lors du chargement : " & ex.Message)
        End Try
    End Sub

    Private Sub btnRecharger_Click(sender As Object, e As EventArgs) Handles btnRecharger.Click
        ChargerUtilisateurs()
    End Sub

    ' 🔹 Ajouter un utilisateur
    Private Sub btnAjouter_Click(sender As Object, e As EventArgs) Handles btnAjouter.Click
        Dim frm As New FrmGestionUtilisateurs()
        If frm.ShowDialog() = DialogResult.OK Then
            ChargerUtilisateurs()
        End If
    End Sub

    ' 🔹 Modifier un utilisateur
    Private Sub btnModifier_Click(sender As Object, e As EventArgs) Handles btnModifier.Click
        Throw New NotImplementedException()
        'If dgvUtilisateurs.SelectedRows.Count = 0 Then Return

        'Dim Id = CInt(dgvUtilisateurs.SelectedRows(0).Cells("Id").Value)
        'Dim nom = dgvUtilisateurs.SelectedRows(0).Cells("NomUtilisateur").Value.ToString()
        'Dim role = dgvUtilisateurs.SelectedRows(0).Cells("Role").Value.ToString()
        'Dim actif = CBool(dgvUtilisateurs.SelectedRows(0).Cells("Actif").Value)

        'TODO : ne compile pas car FrmGestionUtilisateurs n'a pas de constructeur avec paramètres   
        'Dim frm As New FrmGestionUtilisateurs(Id, nom, role, actif)
        'If frm.ShowDialog() = DialogResult.OK Then
        '    ChargerUtilisateurs()
        'End If
    End Sub

    ' 🔹 Supprimer (désactiver) un utilisateur
    Private Sub btnSupprimer_Click(sender As Object, e As EventArgs) Handles btnSupprimer.Click
        If dgvUtilisateurs.SelectedRows.Count = 0 Then Return

        Dim id = CInt(dgvUtilisateurs.SelectedRows(0).Cells("Id").Value)
        Dim nom = dgvUtilisateurs.SelectedRows(0).Cells("NomUtilisateur").Value.ToString()

        If MessageBox.Show($"Désactiver l'utilisateur {nom} ?", "Confirmation",
                       MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Try
                Dim nb As Integer =
                CreateUtilisateurRepository().MettreAJourActif(id, False)

                Logger.INFO($"Utilisateur désactivé Id={id}, lignes={nb}")
                ChargerUtilisateurs()

            Catch ex As Exception
                Dim unused = MessageBox.Show("Erreur lors de la suppression : " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnFermer_Click(sender As Object, e As EventArgs) Handles btnFermer.Click
        Close()
    End Sub
End Class
