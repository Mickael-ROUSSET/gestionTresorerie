﻿Imports System.Data.SqlClient
Imports System.IO

Public Class SqlAdminService

    Private ReadOnly _connectionFactory As IConnectionFactory

    Public Sub New(connectionFactory As IConnectionFactory)
        If connectionFactory Is Nothing Then
            Throw New ArgumentNullException(NameOf(connectionFactory))
        End If

        _connectionFactory = connectionFactory
    End Sub

    Public Sub SauvegarderBase(dbName As String, backupPath As String)
        If String.IsNullOrWhiteSpace(dbName) Then
            Throw New ArgumentException("Le nom de base est obligatoire.", NameOf(dbName))
        End If

        If String.IsNullOrWhiteSpace(backupPath) Then
            Throw New ArgumentException("Le chemin de sauvegarde est obligatoire.", NameOf(backupPath))
        End If

        Dim backupDirectory As String = Path.GetDirectoryName(backupPath)
        If Not String.IsNullOrWhiteSpace(backupDirectory) AndAlso Not Directory.Exists(backupDirectory) Then
            Directory.CreateDirectory(backupDirectory)
        End If

        Dim sql As String =
            "BACKUP DATABASE [" & dbName.Replace("]", "]]") & "] TO DISK = @BackupPath WITH INIT"

        Using conn = _connectionFactory.CreateConnection()
            Using cmd As New SqlCommand(sql, conn)
                cmd.Parameters.AddWithValue("@BackupPath", backupPath)
                conn.Open()
                cmd.ExecuteNonQuery()
            End Using
        End Using
    End Sub

    Public Sub RestaurerBase(dbName As String, backupPath As String)
        If String.IsNullOrWhiteSpace(dbName) Then
            Throw New ArgumentException("Le nom de base est obligatoire.", NameOf(dbName))
        End If

        If String.IsNullOrWhiteSpace(backupPath) Then
            Throw New ArgumentException("Le chemin du backup est obligatoire.", NameOf(backupPath))
        End If

        If Not File.Exists(backupPath) Then
            Throw New FileNotFoundException("Fichier de sauvegarde introuvable.", backupPath)
        End If

        Dim setSingleUser As String =
            "ALTER DATABASE [" & dbName.Replace("]", "]]") & "] SET SINGLE_USER WITH ROLLBACK IMMEDIATE"

        Dim restoreSql As String =
            "RESTORE DATABASE [" & dbName.Replace("]", "]]") & "] FROM DISK = @BackupPath WITH REPLACE"

        Dim setMultiUser As String =
            "ALTER DATABASE [" & dbName.Replace("]", "]]") & "] SET MULTI_USER"

        Using conn = _connectionFactory.CreateConnection()
            conn.Open()

            Using cmd1 As New SqlCommand(setSingleUser, conn)
                cmd1.ExecuteNonQuery()
            End Using

            Using cmd2 As New SqlCommand(restoreSql, conn)
                cmd2.Parameters.AddWithValue("@BackupPath", backupPath)
                cmd2.ExecuteNonQuery()
            End Using

            Using cmd3 As New SqlCommand(setMultiUser, conn)
                cmd3.ExecuteNonQuery()
            End Using
        End Using
    End Sub

End Class