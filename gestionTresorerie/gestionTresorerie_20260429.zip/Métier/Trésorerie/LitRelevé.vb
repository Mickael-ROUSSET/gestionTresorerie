﻿Imports System.IO
Imports System.Security
Imports System.Text
Imports System.Text.RegularExpressions

Friend Module LitRelevé
    Private WithEvents SelectButton As Button
    Private ReadOnly openFileDialog1 As OpenFileDialog

    Sub New()
        openFileDialog1 = New OpenFileDialog() With
        {
           .FileName = "Sélectionner un fichier csv",
           .Filter = "Text files (*.csv)|*.csv",
           .Title = "Open csv file"
        }

        SelectButton = New Button() With {.Text = "Select file"}
    End Sub

    Public Function OuvreFichier() As String
        Dim ficRelevéTraité As String = LectureProprietes.GetCheminEtVariable("ficRelevéTraité")
        'Un seul fichier peut être sélectionné
        openFileDialog1.Multiselect = False
        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            Try
                Dim filePath = openFileDialog1.FileName
                'On vide le fichier avant de le recréer 
                Call ViderFichier(ficRelevéTraité)
                TraiteFichierPourri(ficRelevéTraité, filePath)
            Catch SecEx As SecurityException
                Dim unused = MessageBox.Show($"Security error:{vbCrLf}{SecEx.Message}{vbCrLf}" & $"Details:{vbCrLf}{SecEx.StackTrace}")
                Logger.ERR($"Security error:{SecEx.Message}, Details:{SecEx.StackTrace}")
            End Try
        End If
        Return ficRelevéTraité
    End Function
    Public Sub ViderFichier(ByVal cheminFichier As String)
        Try
            ' Ouvrir le fichier en mode écriture pour le vider 
            System.IO.File.WriteAllText(cheminFichier, String.Empty)
            Logger.INFO($"Le fichier {cheminFichier} a été vidé avec succès.")
        Catch ex As Exception
            ' Gérer les exceptions en cas d'erreur 
            Dim unused = MsgBox($"ViderFichier, erreur : {ex.Message}")
            Logger.ERR($"ViderFichier, erreur : {ex.Message}")
        End Try
    End Sub
    Private Sub TraiteFichierCsvMensuel(sFicTemp As String, sFichier As String)
        Dim sLigneEntiere As New StringBuilder()
        Dim bLigne1 As Boolean = True

        Try
            Using monStreamReader As New StreamReader(sFichier) ' Stream pour la lecture
                Using file As New StreamWriter(sFicTemp, True)
                    Dim ligne As String = monStreamReader.ReadLine()
                    While ligne IsNot Nothing
                        ' Match ignoring case of letters.
                        Dim match As Match = Regex.Match(ligne, Constantes.Formats.RegDateReleve & ";", RegexOptions.IgnoreCase)
                        If match.Success Then
                            ' On est au début d'une ligne => on écrit la ligne en cours et on en commence une autre
                            ' Mais pas sur la 1ère qui contient des entêtes
                            If Not bLigne1 Then
                                file.WriteLine(sLigneEntiere.ToString())
                            Else
                                bLigne1 = False
                            End If
                            Dim unused3 = sLigneEntiere.Clear()
                            Dim unused2 = sLigneEntiere.Append(ligne)
                        Else
                            Dim unused1 = sLigneEntiere.Append(ligne)
                        End If
                        ligne = monStreamReader.ReadLine()
                    End While
                End Using
            End Using
        Catch ex As Exception
            Dim unused = MsgBox($"Une erreur est survenue sur la lecture du relevé : {sFichier}", MsgBoxStyle.Critical)
            Logger.ERR($"Une erreur est survenue sur la lecture du relevé : {sFichier}")
        End Try
    End Sub
    Private Sub TraiteFichierPourri(sFicTemp As String, sFichier As String)
        Dim sLigneEntiere As New System.Text.StringBuilder()
        'Dim bLigne1 As Boolean = True

        Try
            Using monStreamReader As New StreamReader(sFichier) ' Stream pour la lecture
                Dim ligne As String ' Variable contenant le texte de la ligne
                Using file As New System.IO.StreamWriter(sFicTemp, True)
                    Logger.INFO($"Traitement du fichier : {sFicTemp}")

                    ligne = monStreamReader.ReadLine
                    While ligne IsNot Nothing
                        ' Détection de la date du mouvement qui est le début d'une ligne => déclenche l'écriture
                        Dim match As Match = Regex.Match(ligne, Constantes.Formats.RegDateReleve, RegexOptions.IgnoreCase)
                        If match.Success Then
                            ' On est au début d'une ligne => on écrit la ligne en cours et on en commence une autre
                            file.WriteLine(sLigneEntiere.ToString())
                            Dim unused3 = sLigneEntiere.Clear()
                            Dim unused2 = sLigneEntiere.Append(formatteLigne(ligne, True))
                        Else
                            Dim unused1 = sLigneEntiere.Append(formatteLigne(ligne, False))
                        End If
                        ligne = monStreamReader.ReadLine
                    End While
                    ' Écrire la dernière ligne en cours
                    file.WriteLine(sLigneEntiere.ToString())
                End Using
            End Using
        Catch ex As Exception
            Dim unused = MsgBox($"TraiteFichierPourri : Une erreur est survenue sur la lecture du relevé : {sFichier}", MsgBoxStyle.Critical)
            Logger.ERR($"TraiteFichierPourri : Une erreur est survenue sur la lecture du relevé : {sFichier}")
        End Try
    End Sub

    Private Function formatteLigne(sLigne As String, bPresenceDate As Boolean) As String
        Dim sLigneFormattee As String = String.Empty, sTmp As String

        'Il faut alimenter séparément les débits et les crédits et enlever les signes et la monnaie
        If InStr(sLigne, Constantes.Symboles.Tiret, CompareMethod.Text) > 0 Then
            sTmp = sLigne.Replace(Constantes.Symboles.Euro, String.Empty)
            sLigneFormattee = sLigneFormattee & Constantes.Symboles.PointVirgule & sTmp.Replace(Constantes.Symboles.Tiret, String.Empty) & Constantes.Symboles.PointVirgule
        ElseIf InStr(sLigne, Constantes.Symboles.Plus, CompareMethod.Text) > 0 Then
            sTmp = sLigne.Replace(Constantes.Symboles.Euro, String.Empty)
            sLigneFormattee = sLigneFormattee & Constantes.Symboles.PointVirgule & Constantes.Symboles.PointVirgule & sTmp.Replace("+", String.Empty)
        Else
            sLigneFormattee = If(bPresenceDate, sLigneFormattee & sLigne & Constantes.Symboles.PointVirgule, sLigneFormattee & sLigne & Constantes.Symboles.Espace)
        End If
        Return sLigneFormattee
    End Function
End Module
