﻿Imports Microsoft.VisualStudio.TestTools.UnitTesting

<Assembly: Parallelize(Scope:=ExecutionScope.MethodLevel)>
